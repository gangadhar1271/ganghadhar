<?php

	$link=mysqli_connect("localhost","root","","lol") or die("Error: cannot establish database connection :(".mysqli_connect_error());

?>